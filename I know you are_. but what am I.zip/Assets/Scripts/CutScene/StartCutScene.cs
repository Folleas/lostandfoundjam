﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartCutScene : MonoBehaviour {
    public GameObject player;
    private PlayerMovement playerMovement;
    public float positionXInFrontOfMiror;
    public float positionXTowardsCave;
    public bool firstCutScene = false;
    public bool endCutscene = false;
    public bool firstPartStatus = false;
    public Animator transition;
    public float transitionDuration = 1;
    // Start is called before the first frame update
    void Start() {
        playerMovement = player.GetComponent<PlayerMovement>();
        playerMovement.cutScene = true;
    }

    // Update is called once per frame
    void Update() {
        if (!firstPartStatus) {
            if (playerMovement.gameObject.transform.position.x >= positionXInFrontOfMiror)
                playerMovement.horizontalMove = -1 * playerMovement.runSpeed;
            else {
                playerMovement.horizontalMove = 0;
            }
        }
        else {
            if (playerMovement.gameObject.transform.position.x <= positionXTowardsCave)
                playerMovement.horizontalMove = playerMovement.runSpeed;
            else {
                playerMovement.horizontalMove = 0;
            }
            if (playerMovement.gameObject.transform.position.x >= 60) {
                StartCoroutine(LoadScene(2, transitionDuration));
            }
        }
        if (firstCutScene && playerMovement.gameObject.transform.position.x <= positionXInFrontOfMiror) {
            StartCoroutine(WaitAndGoLeft());
        }
        else if (endCutscene && playerMovement.gameObject.transform.position.x <= positionXInFrontOfMiror) {
            StartCoroutine(LoadScene(4, 5f));
        }
    }
    IEnumerator LoadScene(int sceneIndex, float transitionLength) {
        transition.SetTrigger("Start");
        yield return new WaitForSeconds(transitionLength);
        SceneManager.LoadScene(sceneIndex);
    }
    private IEnumerator WaitAndGoLeft() {
        yield return new WaitForSeconds(3f);
        firstPartStatus = true;
    }
}
