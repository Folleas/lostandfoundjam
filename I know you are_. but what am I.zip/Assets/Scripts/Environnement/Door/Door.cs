﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour, IDoor
{
    bool isOpen = false;

    public void Open() {
        gameObject.SetActive(false);
    }
    public void Close() {
        gameObject.SetActive(true);
    }
    public void Toggle() {
        isOpen = !isOpen;
        if (isOpen) {
            Open();
        }
        else {
            Close();
        }
    }
}
