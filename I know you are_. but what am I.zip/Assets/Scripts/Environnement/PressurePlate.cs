﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PressurePlate : MonoBehaviour, IInteraction {
    public GameObject doorGameObject;
    public GameObject[] reseted;
    public bool reset = false;
    private IDoor door;
    public bool activeStatus;
    public bool isTrigger;
    public bool toggle;
    private bool played;
    public float interactionTimer = 0;
    public bool destroyPlate = false;
    public bool pressure = false;
    public bool needHead = false;
    public bool needPowerUps = false;
    private void Awake() {
        door = doorGameObject.GetComponent<IDoor>();
    }
    void OnTriggerEnter2D(Collider2D col) {
        if (reset && col.gameObject.tag == "Player") {
            foreach (GameObject obj in reseted) {
                obj.SetActive(false);
            }
        }
        if (needHead && col.gameObject.tag == "Player" && !col.gameObject.GetComponent<Player>().isHeadless) {
            if (needPowerUps && col.gameObject.GetComponent<CharacterData>().characterState >= CharacterState.END) {
                StartCoroutine(Interact());
            }
        }
        else if (!needHead && !needPowerUps) {
            StartCoroutine(Interact());
        }
    }
    void OnTriggerExit2D(Collider2D col) {
        if (pressure) {
            IDestructible destructible = doorGameObject.GetComponent<IDestructible>();
            if (pressure) {
                destructible.Destroy(!activeStatus);
            }
        }
    }
    public IEnumerator Interact() {
        yield return new WaitForSeconds(interactionTimer);
        if (!played && doorGameObject != null) {
            IDestructible destructible = doorGameObject.GetComponent<IDestructible>();
            if (pressure) {
                destructible.Destroy(activeStatus);
            }
            else if (destructible != null && !toggle) {
                if (!activeStatus)
                    gameObject.SetActive(!destroyPlate);
                destructible.Destroy(activeStatus);
            }
            else {
                door.Toggle();
            }
        }
        if (isTrigger)
            played = true;
    }
}
