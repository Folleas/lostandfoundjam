﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestructibleWall : MonoBehaviour, IDestructible
{
    public void Destroy(bool status) {
        Debug.Log("status : " + status);
        gameObject.SetActive(status);
    }
}
