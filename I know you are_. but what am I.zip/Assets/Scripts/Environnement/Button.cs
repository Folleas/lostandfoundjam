﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
public class Button : MonoBehaviour, IInteraction {
    public GameObject ground;
    public GameObject doorGameObject;
    private IDoor door;
    public bool activeStatus;
    public bool isTrigger;
    private bool played = false;
    public float interactionTimer = 0f;
    private void Awake() {
        if (doorGameObject != null)
            door = doorGameObject.GetComponent<IDoor>();
    }
    public IEnumerator Interact() {
        yield return new WaitForSeconds(interactionTimer);
        if (!played && ground != null) {
            IDestructible destructible = ground.GetComponent<IDestructible>();
            if (destructible != null) {
                destructible.Destroy(activeStatus);
            }
        }
        if (door != null) {
            door.Toggle();
        }
        if (isTrigger)
            played = true;
    }
}