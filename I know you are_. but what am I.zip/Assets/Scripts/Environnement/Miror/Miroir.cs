﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Miroir : MonoBehaviour {
    public float radius = 5f;
    [SerializeField] private LayerMask PlayerLayer;
    public GameObject player;
    private GameObject mirroredPlayer = null;
    // Start is called before the first frame update
    void Start() {

    }

    // Update is called once per frame
    void Update() {
        if (Physics2D.OverlapCircle(transform.position, radius, PlayerLayer)) {
            if (mirroredPlayer == null) {
                mirroredPlayer = Instantiate(player);
                mirroredPlayer.layer = 0;
            }
            else {
                mirroredPlayer.transform.position = new Vector3(transform.position.x + transform.position.x - player.transform.position.x, player.transform.position.y, player.transform.position.z);
                mirroredPlayer.GetComponent<PlayerMovement>().horizontalMove = player.GetComponent<PlayerMovement>().horizontalMove;
                if (mirroredPlayer.GetComponent<CharacterController2D>().facingRight == player.GetComponent<CharacterController2D>().facingRight)
                    mirroredPlayer.GetComponent<CharacterController2D>().Flip();
            }
        }
        else {
            Destroy(mirroredPlayer);
            mirroredPlayer = null;
        }
    }
    //void OnDrawGizmosSelected() {
    //    UnityEditor.Handles.color = Color.green;
    //    UnityEditor.Handles.DrawWireDisc(transform.position, transform.up, radius);
    //}
}
