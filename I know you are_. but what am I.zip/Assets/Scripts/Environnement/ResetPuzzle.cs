﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResetPuzzle : MonoBehaviour, IInteraction {
    public GameObject[] objects;
    public bool activeStatus;
    public string reseterTag = "Player";
    private void Awake() {
    }
    void OnTriggerEnter2D(Collider2D col) {
        StartCoroutine(Interact());
    }
    void OnCollisionEnter2D(Collision2D col) {
        Debug.Log("Collision: " + col.gameObject.tag);
        if (col.gameObject.tag == reseterTag)
            StartCoroutine(Interact());
    }
    public IEnumerator Interact() {
        yield return new WaitForSeconds(0);
        foreach (GameObject obj in objects) {
            obj.SetActive(!activeStatus);
        }
    }
}