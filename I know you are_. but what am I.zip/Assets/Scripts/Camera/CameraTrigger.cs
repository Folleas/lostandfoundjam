﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraTrigger : MonoBehaviour
{
    public SmoothCamera2D camera;
    public Transform target;

    private void OnTriggerEnter2D(Collider2D collision) {
        if (camera != null && target != null) {
            camera.target = target;
        }
    }
}
