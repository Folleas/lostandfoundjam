﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MusicPlayer : MonoBehaviour {
    public AudioSource audioSource1;
    public AudioSource audioSource2;
    public AudioSource currentAudioSource;
    float currentMusicTime;
    bool musicChanged = false;

    void OnLevelWasLoaded() {
        currentAudioSource.time = currentMusicTime;
    }
    void Start() {
        DontDestroyOnLoad(gameObject);
        currentAudioSource = audioSource1;
        currentAudioSource.Play();
    }
    // Update is called once per frame
    void Update() {
        currentMusicTime = currentAudioSource.time;
        if (SceneManager.GetActiveScene().buildIndex == 2 && !musicChanged) {
            currentAudioSource.Stop();
            currentAudioSource = audioSource2;
            currentAudioSource.Play();
            musicChanged = true;
        }
    }
}
