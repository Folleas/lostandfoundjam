﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour {
    public Animator transition;
    public float transitionDuration = 1;
    public void Play() {
        StartCoroutine(LoadScene());
    }
    public void Exit() {
        Application.Quit();
    }
    IEnumerator LoadScene() {
        transition.SetTrigger("Start");
        yield return new WaitForSeconds(transitionDuration);
        SceneManager.LoadScene(1);
    }
}
