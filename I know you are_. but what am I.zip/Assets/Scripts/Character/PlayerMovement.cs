﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {
    public CharacterController2D controller;
    public Animator animator;

    public float runSpeed = 40f;
    public float horizontalMove = 0f;
    bool jump = false;
    bool crouch = false;
    bool prepJump = false;

    public bool cutScene = false;
    public float startJumpForce;
    public float endJumpForce;

    // Start is called before the first frame update
    void Start() {

    }

    // Update is called once per frame
    void Update() {
        animator.SetFloat("Speed", Mathf.Abs(horizontalMove));
        if (cutScene)
            return;
        if (gameObject.GetComponent<Player>().animationDone) {
            horizontalMove = Input.GetAxisRaw("Horizontal") * runSpeed;

            if (gameObject.GetComponent<CharacterData>().characterState >= CharacterState.END) {
                gameObject.GetComponent<CharacterController2D>().m_JumpForce = endJumpForce;
                if (Input.GetButtonDown("Jump") && !prepJump && gameObject.GetComponent<CharacterController2D>().grounded) {
                    animator.SetTrigger("PrepJump");
                    prepJump = true;
                }
                else if (Input.GetButtonUp("Jump")) {
                    jump = true;
                    prepJump = false;
                }
            }
            else {
                if (Input.GetButtonDown("Jump") && gameObject.GetComponent<CharacterController2D>().grounded) {
                    gameObject.GetComponent<CharacterController2D>().m_JumpForce = startJumpForce;
                    jump = true;
                }
            }
            if (gameObject.GetComponent<CharacterData>().characterState >= CharacterState.START) {
                if (Input.GetButtonDown("Crouch")) {
                    StartCoroutine(gameObject.GetComponent<Player>().Interact(1.7f, true, "CrouchedButton"));
                    crouch = true;
                }
                else if (Input.GetButtonUp("Crouch")) {
                    crouch = false;
                }
            }
        }
        else {
            horizontalMove = 0;
        }
    }

    private void FixedUpdate() {
        float movement;

        if (prepJump)
            movement = 0;
        else
            movement = horizontalMove * Time.fixedDeltaTime;
        CharacterState characterState = gameObject.GetComponent<CharacterData>().characterState;
        bool statusJump = false;
        if (characterState >= CharacterState.END)
            statusJump = true;
        controller.Move(movement, crouch, jump, statusJump);
        jump = false;
    }
}