﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeadProjectile : MonoBehaviour, IInteraction {
    [Range(0, .3f)] [SerializeField] private float m_MovementSmoothing = .05f;
    public float interactionTimer = 0.1f;
    public float _move;
    public float move {
        get {
            return _move;
        }
        set {
            _move = value;
        }
    }
    private Rigidbody2D rigidBody;
    private Vector3 m_Velocity = Vector3.zero;
    // Start is called before the first frame update
    void Start() {
        rigidBody = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update() {
        Vector3 targetVelocity = new Vector2(_move, rigidBody.velocity.y);
        rigidBody.velocity = Vector3.SmoothDamp(rigidBody.velocity, targetVelocity, ref m_Velocity, m_MovementSmoothing);
    }

    private void OnCollisionEnter2D(Collision2D collision) {
        IDestructible destructible = collision.gameObject.GetComponent<IDestructible>();
        if (destructible != null) {
            destructible.Destroy(false);
            move = 0f;
        }
        Debug.Log(collision.gameObject.tag);
        if (collision.gameObject.tag == "ResetPuzzle") {
            move = 0f;
        }
    }
    public IEnumerator Interact() {
        yield return new WaitForSeconds(interactionTimer);
        Destroy(gameObject);
    }
}
