﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUpTrigger : MonoBehaviour
{
    public GameObject powerUp;
    public Transform target;
    bool done = false;

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.gameObject.tag == "Player" && !done) {
            done = true;
            GameObject obj = Instantiate(powerUp);
            powerUp.transform.position = target.position;
        }
    }
}
