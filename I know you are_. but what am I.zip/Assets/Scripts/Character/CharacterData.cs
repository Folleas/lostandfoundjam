﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;
public enum CharacterState {
    UNDEFINED,
    START,
    MIDDLE,
    END
};

public class CharacterData : MonoBehaviour {
    public CharacterState characterState {
        get {
            return _characterState;
        }
    }
    private CharacterState _characterState = CharacterState.UNDEFINED;

    public void EvolveCharacter() {
        if (_characterState < CharacterState.END) {
            _characterState = Enum.GetValues(typeof(CharacterState)).Cast<CharacterState>().First(e => (int)e > (int)_characterState);
        }
    }
}
