﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {
    public Transform headSpawnTransform;
    public Animator animator;
    public GameObject head;
    private bool _IsPushing = false;
    private bool _animationDone = true;
    public bool animationDone {
        get {
            return _animationDone;
        }
        set {
            _animationDone = value;
        }
    }
    public bool IsPushing {
        get {
            return _IsPushing;
        }
        set {
            _IsPushing = value;
        }
    }
    public bool isHeadless {
        get {
            return _isHeadless;
        }
    }
    private bool _isHeadless;
    // Start is called before the first frame update
    void Start() {

    }

    public IEnumerator Interact(float waitTime, bool crouched = false, string searchedTag = "Button") {
        if (gameObject.GetComponent<CharacterController2D>().Interation(searchedTag, 1, crouched)) {
            if (!crouched)
                animator.SetTrigger("PushButton");
            else
                animator.SetTrigger("Crouch");
            _IsPushing = true;
        }
        yield return new WaitForSeconds(waitTime);
        _IsPushing = false;
    }

    private IEnumerator LaunchHead(float waitTime) {
        animator.SetTrigger("HeadRoll");
        yield return new WaitForSeconds(waitTime);
        _animationDone = true;
        ThrowHead();
    }

    // Update is called once per frame
    void Update() {
        if (Input.GetKeyDown(KeyCode.E) && !IsPushing && _animationDone) {
            StartCoroutine(Interact(1.7f));
        }
        if (Input.GetKeyDown(KeyCode.R) && _animationDone && gameObject.GetComponent<CharacterController2D>().grounded && gameObject.GetComponent<CharacterData>().characterState >= CharacterState.MIDDLE) {
            if (!_isHeadless) {
                animator.SetBool("Headless", true);
                _animationDone = false;
                StartCoroutine(LaunchHead(2f));
                _isHeadless = true;
            }   
            else {
                animator.SetBool("Headless", false);
                if (gameObject.GetComponent<CharacterController2D>().Interation("PlayerHead", 0)) {
                    GameObject.FindGameObjectWithTag("MainCamera").GetComponent<SmoothCamera2D>().target = transform;
                    _isHeadless = false;
                }
            }
        }
    }
    void ThrowHead() {
        HeadProjectile headProjectile = Instantiate(head).GetComponent<HeadProjectile>();
        GameObject.FindGameObjectWithTag("MainCamera").GetComponent<SmoothCamera2D>().target = headProjectile.transform;
        headProjectile.transform.position = headSpawnTransform.position;
        headProjectile.move *= transform.localScale.x;
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.gameObject.tag == "PowerUp") {
            GetComponent<CharacterData>().EvolveCharacter();
            Destroy(collision.gameObject);
        }
    }
}
