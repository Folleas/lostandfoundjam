﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Dialog : MonoBehaviour
{
    public TextMeshProUGUI textDisplay;
    public string[] sentences;
    private int index;
    public float typingSpeed = 0.5f;
    public Animator textDisplayAnimation;

    private void Start() {
        StartCoroutine(Type(typingSpeed));
    }

    IEnumerator Type(float typingSpeed) {
        foreach (char letter in sentences[index].ToCharArray()) {
            if (letter == '[')
                break;
            textDisplay.text += letter;
            yield return new WaitForSeconds(typingSpeed);
        }
        yield return new WaitForSeconds(sentences[index].Length / 10f);
        if (!sentences[index].Contains("[next]")) {
            textDisplay.text = "";
        }
        index++;
        if (index < sentences.Length) {
            textDisplayAnimation.SetTrigger("Next");
            StartCoroutine(Type(typingSpeed));
        }
    }
}
